# Filename: support.py

def sum_abc(a,b,c):
    return(a + b + c)

